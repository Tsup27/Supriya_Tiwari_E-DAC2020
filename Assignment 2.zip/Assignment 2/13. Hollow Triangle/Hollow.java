class Hollow{

     public static void main(String []args){
        int max = 6;
        for(int i=1; i<=max; i++ )
        {
            for(int j=max; j>=i;j--)
            {   
                System.out.print(" ");
            }
            for(int j=2;j<=i*2;j++)
            {
                
                if(j==2)
                {
                  System.out.print("*");  
                }
                else if(j<(i*2)-1)
                {
                    
                    if(i==max && j%2==0)
                    {
                        System.out.print("*");  
                    }
                    else
                    {
                        System.out.print(" ");
                    }
                }
                else if(j==(i*2)-1)
                {
                    System.out.print(" *");  
                }
            }
            System.out.println();
        }
     }
}