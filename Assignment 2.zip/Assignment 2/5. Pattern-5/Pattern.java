class Pattern
{
	public static void main(String args[])
	{
		int max=9;
		for(int i=9; i>=1;i--)
		{
		    for(int j=max-i;j<=9;j++)
		    {
		        System.out.print("  ");
		    }
		    for(int j=i;j<=max;j++)
		    {
		        System.out.print(j+" ");
		    }
		    for(int j=max-1;j>=i;j--)
		    {
		        System.out.print(j+" ");
		    }
		   System.out.println();
		    
		}
		
	}
}